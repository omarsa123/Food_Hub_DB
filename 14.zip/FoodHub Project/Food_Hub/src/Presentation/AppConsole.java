package Presentation;

import Entity.*;
import Enums.*;
import ReportsQueries.ReportsQueries;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.math.BigDecimal;
import java.util.*;

public class AppConsole {

    private static final Scanner scanner = new Scanner(System.in);
    private static Employye currentEmployee = null;

    private static String generateOrderId() {
        return "ORD-" + System.currentTimeMillis();
    }

    private static String generateMealId() {
        return "ML-" + UUID.randomUUID().toString().substring(0, 5).toUpperCase();
    }

    public static void startMenu(EntityManager em) {
        while (true) {
            System.out.println("\n====================================");
            System.out.println("      WELCOME TO FOODHUB SYSTEM      ");
            System.out.println("====================================");
            System.out.println("1. Staff Login (Management)");
            System.out.println("2. Customer Portal (Ordering)");
            System.out.println("3. Exit");
            System.out.print("Select: ");

            String input = scanner.nextLine();

            if (input.equals("1")) {
                if (employeeLogin(em)) employeeMenu(em);
            } else if (input.equals("2")) {
                customerMenu(em);
            } else if (input.equals("3")) {
                break;
            }
        }
    }

    private static boolean employeeLogin(EntityManager em) {
        System.out.print("Enter Employee ID: ");
        String id = scanner.nextLine();

        Employye emp = em.find(Employye.class, id);

        if (emp != null) {
            currentEmployee = emp;
            System.out.println("Welcome " + emp.getName() + " [" + emp.getType() + "]");
            return true;
        }

        System.out.println("Invalid Employee ID");
        return false;
    }

    private static void employeeMenu(EntityManager em) {

        while (true) {

            EmpType role = currentEmployee.getType();

            System.out.println("\n--- DASHBOARD (" + role + ") ---");
            System.out.println("1. Reports (Manager)");
            System.out.println("2. Customers");
            System.out.println("3. Categories");
            System.out.println("4. Meals");
            System.out.println("5. Orders");
            System.out.println("6. Employees (Manager)");
            System.out.println("7. View Data");
            System.out.println("8. Logout");

            String choice = scanner.nextLine();

            if (choice.equals("8")) {
                currentEmployee = null;
                break;
            }

            switch (choice) {

                case "1":
                    if (role == EmpType.Manager) reportsMenu(em);
                    else System.out.println("Access Denied");
                    break;

                case "2":
                    manageCustomersMenu(em);
                    break;

                case "3":
                    manageCategoriesMenu(em);
                    break;

                case "4":
                    manageMealsMenu(em);
                    break;

                case "5":
                    manageOrdersMenu(em);
                    break;

                case "6":
                    if (role == EmpType.Manager) manageEmployeesCRUD(em);
                    else System.out.println("Access Denied");
                    break;

                case "7":
                    viewAllRecordsMenu(em);
                    break;
            }
        }
    }

    private static void manageEmployeesCRUD(EntityManager em) {

        while (true) {
            System.out.println("\n--- EMPLOYEES ---");
            System.out.println("1. List | 2. Add | 3. Update | 4. Delete | 5. Back");

            String op = scanner.nextLine();
            if (op.equals("5")) break;

            switch (op) {

                case "1":
                    Employye.getAllEmployees(em)
                            .forEach(e -> System.out.println(e.getID() + " | " + e.getName() + " | " + e.getType()));
                    break;

                case "2":
                    System.out.print("Name: ");
                    String n = scanner.nextLine();

                    System.out.print("Phone: ");
                    String p = scanner.nextLine();

                    System.out.print("Address: ");
                    String a = scanner.nextLine();

                    System.out.print("Type (Manager/Employee): ");
                    String t = scanner.nextLine();

                    Employye emp = new Employye(Employye.generateID(), n, p, a);

                    if (t.equalsIgnoreCase("manager"))
                        emp.setType(EmpType.Manager);
                    else
                        emp.setType(EmpType.Employee);

                    emp.insert(em);
                    System.out.println("Employee Added");
                    break;

                case "3":
                    System.out.print("ID: ");
                    String uid = scanner.nextLine();

                    System.out.print("New Name: ");
                    String nn = scanner.nextLine();

                    System.out.print("New Phone: ");
                    String np = scanner.nextLine();

                    Employye.updateEmployee(em, uid, nn, np);
                    break;

                case "4":
                    System.out.print("ID: ");
                    Employye.deleteById(em, scanner.nextLine());
                    break;
            }
        }
    }

    private static void reportsMenu(EntityManager em) {

        while (true) {
            System.out.println("\n--- REPORTS ---");
            System.out.println("1. KPI | 2. Top Selling | 3. Monthly | 4. Back");

            String r = scanner.nextLine();
            if (r.equals("4")) break;

            switch (r) {

                case "1":
                    System.out.println("Revenue: " + ReportsQueries.getTotalRevenue(em));
                    System.out.println("Orders: " + ReportsQueries.getTotalOrdersCount(em));
                    System.out.println("Customers: " + ReportsQueries.getTotalCustomersCount(em));
                    break;

                case "2":
                    ReportsQueries.getTopSellingMeals(em)
                            .forEach(x -> System.out.println(x[0] + " -> " + x[1]));
                    break;

                case "3":
                    ReportsQueries.getCompletedOrdersPerMonth(em)
                            .forEach(x -> System.out.println(x[0] + " : " + x[1]));
                    break;
            }
        }
    }

    private static void viewAllRecordsMenu(EntityManager em) {

        boolean isManager = currentEmployee.getType() == EmpType.Manager;

        System.out.println("\n1. Customers");
        System.out.println("2. Invoices");
        System.out.println("3. Orders");
        System.out.println("4. Categories");
        System.out.println("5. Meals");
        System.out.println("6. Employees");
        System.out.println("7. Back");

        String op = scanner.nextLine();

        switch (op) {

            case "1":
                Customers.getAllCustomers(em)
                        .forEach(c -> System.out.println(c.getName() + " | " + c.getPhone()));
                break;

            case "2":
                String iq = isManager
                        ? "SELECT i FROM Invoice i"
                        : "SELECT i FROM Invoice i WHERE i.orderId.employee.id = :id";

                var q1 = em.createQuery(iq, Invoice.class);

                if (!isManager)
                    q1.setParameter("id", currentEmployee.getID());

                q1.getResultList()
                        .forEach(i -> System.out.println(i.getId() + " | " + i.getTotalPrice()));
                break;

            case "3":
                String oq = isManager
                        ? "SELECT o FROM Orders o"
                        : "SELECT o FROM Orders o WHERE o.employee.id = :id";

                var q2 = em.createQuery(oq, Orders.class);

                if (!isManager)
                    q2.setParameter("id", currentEmployee.getID());

                q2.getResultList()
                        .forEach(o -> System.out.println(o.getId() + " | " + o.getStatus()));
                break;

            case "4":
                Categories.getAllCategories(em)
                        .forEach(c -> System.out.println(c.getId() + " | " + c.getName()));
                break;

            case "5":
                showMenu(em);
                break;

            case "6":
                if (isManager)
                    Employye.getAllEmployees(em)
                            .forEach(e -> System.out.println(e.getID() + " | " + e.getName() + " | " + e.getType()));
                else
                    System.out.println("Access Denied");
                break;
        }
    }

    private static void createNewOrder(EntityManager em) {

        System.out.print("Phone: ");
        String phone = scanner.nextLine();

        List<Customers> list = em.createQuery(
                        "SELECT c FROM Customers c WHERE c.phone = :p", Customers.class)
                .setParameter("p", phone)
                .getResultList();

        if (list.isEmpty()) {
            System.out.println("Customer not found");
            return;
        }

        Customers customer = list.get(0);

        Orders order = new Orders(generateOrderId());
        order.setCustomerId(customer);
        order.setEmployee(currentEmployee);
        order.setOrderItemsSet(new HashSet<>());

        while (true) {

            System.out.print("Meal ID (n to stop): ");
            String mid = scanner.nextLine();

            if (mid.equalsIgnoreCase("n")) break;

            Meals m = em.find(Meals.class, mid);

            if (m != null) {

                System.out.print("Qty: ");
                int q = Integer.parseInt(scanner.nextLine());

                OrderItems item = new OrderItems(order.getId(), m.getId());
                item.setMeals(m);
                item.setQuantity(q);
                item.setOrders(order);

                order.getOrderItemsSet().add(item);
            }
        }

        order.updateForOrederItems();

        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            order.insert(em);

            Invoice inv = new Invoice("INV-" + order.getId().replace("ORD-", ""));
            inv.setOrderId(order);
            inv.insert(em, 14.0, new BigDecimal("10"));

            tx.commit();

            System.out.println("Order Created | Total: " + order.getSubtotal());

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            e.printStackTrace();
        }
    }

    private static void customerMenu(EntityManager em) {

        while (true) {
            System.out.println("\n1. Menu | 2. Order | 3. Register | 4. Back");

            String c = scanner.nextLine();

            if (c.equals("4")) break;
            if (c.equals("1")) showMenu(em);
            else if (c.equals("2")) createNewOrder(em);
            else if (c.equals("3")) addNewCustomer(em);
        }
    }

    private static void manageCustomersMenu(EntityManager em) {
        while (true) {
            System.out.println("\n--- CUSTOMERS ---");
            System.out.println("1. List | 2. Add | 3. Update | 4. Delete | 5. Back");

            String op = scanner.nextLine();
            if (op.equals("5")) break;

            switch (op) {
                case "1":
                    Customers.getAllCustomers(em)
                            .forEach(c -> System.out.println(c.getName() + " | " + c.getPhone()));
                    break;

                case "2":
                    addNewCustomer(em);
                    break;
            }
        }
    }

    private static void manageMealsMenu(EntityManager em) {
        while (true) {
            System.out.println("\n--- MEALS ---");
            System.out.println("1. Add | 2. Edit | 3. Delete | 4. Back");

            String op = scanner.nextLine();
            if (op.equals("4")) break;

            switch (op) {
                case "1": addNewMeal(em); break;
                case "2": editMeal(em); break;
                case "3": Meals.deleteById(em, scanner.nextLine()); break;
            }
        }
    }

    private static void manageCategoriesMenu(EntityManager em) {
        while (true) {
            System.out.println("\n--- CATEGORIES ---");
            System.out.println("1. Add | 2. Edit | 3. Delete | 4. Back");

            String op = scanner.nextLine();
            if (op.equals("4")) break;

            switch (op) {
                case "1": addCategory(em); break;
                case "2": editCategory(em); break;
                case "3": Categories.deleteById(em, Integer.parseInt(scanner.nextLine())); break;
            }
        }
    }

private static void manageOrdersMenu(EntityManager em) {
    while (true) {
        System.out.println("\n--- MANAGE ORDERS ---");
        System.out.println("1. View All Orders");
        System.out.println("2. Assign Order to Employee (Manager)");
        System.out.println("3. Update Order Status (Delivered/Cancelled)");
        System.out.println("4. Delete Order");
        System.out.println("5. Back");
        System.out.print("Choose: ");
        String op = scanner.nextLine();

        if (op.equals("5")) break;

        switch (op) {
            case "1":
                viewAllOrders(em);
                break;

            case "2":   
                if (currentEmployee.getType() == EmpType.Manager) {
                    assignOrderToEmployee(em);
                } else {
                    System.out.println("Access Denied: Only Manager can assign orders");
                }
                break;

            case "3":
                System.out.print("Order ID: ");
                String oid = scanner.nextLine();
                Orders o = em.find(Orders.class, oid);
                if (o == null) {
                    System.out.println("Order not found");
                    break;
                }
                System.out.println("1. Delivered | 2. Cancelled");
                String st = scanner.nextLine();
                if (st.equals("1")) o.updateOrderStatus(em, OrderStatus.delivered);
                else if (st.equals("2")) o.updateOrderStatus(em, OrderStatus.cancelled);
                break;

            case "4":
                System.out.print("Order ID: ");
                String delId = scanner.nextLine();
                Orders ord = em.find(Orders.class, delId);
                if (ord != null) {
                    EntityTransaction tx = em.getTransaction();
                    tx.begin();
                    em.remove(ord);
                    tx.commit();
                    System.out.println("Order deleted");
                }
                break;
        }
    }
}
private static void assignOrderToEmployee(EntityManager em) {
    System.out.print("Enter Order ID: ");
    String orderId = scanner.nextLine();

    Orders order = em.find(Orders.class, orderId);
    if (order == null) {
        System.out.println("Order not found!");
        return;
    }

    System.out.println("Current Employee: " + 
        (order.getEmployee() != null ? order.getEmployee().getName() : "Not Assigned"));
    System.out.println("\nAvailable Employees:");
    List<Employye> employees = Employye.getAllEmployees(em);
    for (Employye emp : employees) {
        System.out.println(emp.getID() + " | " + emp.getName() + " [" + emp.getType() + "]");
    }

    System.out.print("\nEnter Employee ID to assign: ");
    String empId = scanner.nextLine();

    Employye newEmployee = em.find(Employye.class, empId);
    if (newEmployee == null) {
        System.out.println("Employee not found!");
        return;
    }

    EntityTransaction tx = em.getTransaction();
    try {
        tx.begin();
        order.setEmployee(newEmployee);
        em.merge(order);         
        tx.commit();

        System.out.println("Order successfully assigned to: " + newEmployee.getName());
    } catch (Exception e) {
        if (tx.isActive()) tx.rollback();
        System.out.println("Error while assigning order");
        e.printStackTrace();
    }
}

    private static void addNewCustomer(EntityManager em) {
        System.out.print("Name: ");
        String n = scanner.nextLine();

        System.out.print("Phone: ");
        String p = scanner.nextLine();

        Customers c = new Customers();
        c.setName(n);
        c.setPhone(p);
        c.insert(em);
    }
    private static void addNewMeal(EntityManager em) {

    System.out.print("Meal Name: ");
    String n = scanner.nextLine();

    System.out.print("Price: ");
    BigDecimal pr = new BigDecimal(scanner.nextLine());

    Categories.getAllCategories(em)
            .forEach(cat -> System.out.println(cat.getId() + " - " + cat.getName()));

    System.out.print("Select Category ID: ");
    int cid = Integer.parseInt(scanner.nextLine());

    Categories selectedCat = em.find(Categories.class, cid);

    if (selectedCat != null) {
        Meals m = new Meals(generateMealId());
        m.setName(n);
        m.setPrice(pr);
        m.setCategoryId(selectedCat);
        m.insert(em);
    }
}
    private static void showMenu(EntityManager em) {
        Categories.getAllCategories(em).forEach(cat -> {
            System.out.println("\n--- " + cat.getName() + " ---");
            ReportsQueries.getMealsByCategory(em, cat.getId())
                    .forEach(m -> System.out.println(m.getId() + " " + m.getName() + " " + m.getPrice()));
        });
    }

    private static void addCategory(EntityManager em) {
        System.out.print("Name: ");
        Categories c = new Categories();
        c.setName(scanner.nextLine());
        c.insert(em);
    }
    private static void editMeal(EntityManager em) {
        System.out.print("ID: ");
        Meals m = em.find(Meals.class, scanner.nextLine());

        if (m != null) {
            System.out.print("New Price: ");
            m.setPrice(new BigDecimal(scanner.nextLine()));

            EntityTransaction tx = em.getTransaction();
            tx.begin();
            em.merge(m);
            tx.commit();
        }
    }
    private static void editCategory(EntityManager em) {
        System.out.print("ID: ");
        Categories c = em.find(Categories.class, Integer.parseInt(scanner.nextLine()));

        if (c != null) {
            System.out.print("New Name: ");
            c.setName(scanner.nextLine());

            EntityTransaction tx = em.getTransaction();
            tx.begin();
            em.merge(c);
            tx.commit();
        }
    }
    private static void viewAllOrders(EntityManager em) {
    System.out.println("\n====================================");
    System.out.println("              ALL ORDERS");
    System.out.println("====================================");

    List<Orders> orders;

    if (currentEmployee.getType() == EmpType.Manager) {
        String jpql = "SELECT o FROM Orders o ORDER BY o.orderPlacedAt DESC";
        orders = em.createQuery(jpql, Orders.class).getResultList();
        System.out.println("Showing All Orders (Manager View)\n");
    } else {
        String jpql = "SELECT o FROM Orders o WHERE o.employee.ID = :empId ORDER BY o.orderPlacedAt DESC";
        
        orders = em.createQuery(jpql, Orders.class)
                   .setParameter("empId", currentEmployee.getID())
                   .getResultList();
        
        System.out.println("Showing Your Assigned Orders Only\n");
    }

    if (orders.isEmpty()) {
        System.out.println("No orders found.");
        return;
    }

    for (Orders o : orders) {
        String empName = "Not Assigned";
        
        if (o.getEmployee() != null) {
            empName = o.getEmployee().getName() + " (" + o.getEmployee().getID() + ")";
        }

        System.out.println("────────────────────────────────────");
        System.out.println("Order ID       : " + o.getId());
        System.out.println("Placed At      : " + o.getOrderPlacedAt());
        System.out.println("Status         : " + o.getStatus());
        System.out.println("Subtotal       : " + o.getSubtotal());
        System.out.println("Customer       : " + o.getCustomerId().getName() + 
                          " (" + o.getCustomerId().getPhone() + ")");
        System.out.println("Assigned To    : " + empName);
        System.out.println("Completed At   : " + 
            (o.getCompletedAt() != null ? o.getCompletedAt() : "Still Open"));
    }
    
    System.out.println("====================================");
    System.out.println("Total Orders Shown: " + orders.size());
}
}